<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\Response;

class DashboardController extends BaseController
{
    public function index()
    {   
        $office = new \App\Models\Office();
        $ticket = new \App\Models\Ticket();
        $data['offices'] = $office->findAll();

        $ticket = new \App\Models\Ticket();
        $data['critical'] = $ticket->where('severity', 'C')->countAllResults();
        $data['high'] = $ticket->where('severity', 'H')->countAllResults();
        $data['medium'] = $ticket->where('severity', 'M')->countAllResults();
        $data['low'] = $ticket->where('severity', 'L')->countAllResults();
        $data['pending'] = $ticket->where('state', 'PENDING')->countAllResults();
        $data['processing'] = $ticket->where('state', 'PROCESSING')->countAllResults();
        $data['resolved'] = $ticket->where('state', 'RESOLVED')->countAllResults();
        $data['totalTicket'] = $ticket->countall();

        return view('dashboard', $data);
    }

    /**
     * Return the properties of a resource object
     *
     * @return mixed
     */
    public function show($id = null)
    {
        $ticket = new \App\Models\Ticket();
        $data = $ticket->find($id);
        if($data){
            $data->join('user_details', 'user_details.id = ticket.user_id');
            $data = $ticket->find($id);
        }
        
        return $this->response->setStatusCode(Response::HTTP_OK)->setJSON($data);
    }

    public function list()
    {
        $postData = $this->request->getPost();

        $draw = $postData['draw'];
        $start = $postData['start'];
        $rowperpage = $postData['length']; // Rows display per page
        $searchValue = $postData['search']['value'];
        $sortby = $postData['order'][0]['column']; // Column index
        $sortdir = $postData['order'][0]['dir']; // asc or desc
        $sortcolumn = $postData['columns'][$sortby]['data']; // Column name 


        $ticket = new \App\Models\Ticket();
        $totalRecords = $ticket->select('id')->countAllResults();

        $totalRecordswithFilter = $ticket->select('ticket.id')
            ->join('user_details', 'user_details.id = ticket.user_id')
            ->join('office', 'office.id = ticket.office_id')
            ->orLike('user_details.last_name', $searchValue)
            ->orLike('user_details.first_name', $searchValue)
            ->orLike('office.office_name', $searchValue)
            ->orLike('ticket.severity', $searchValue)
            ->orLike('ticket.description', $searchValue)
            ->orLike('ticket.state', $searchValue)
            ->orderBy('ticket.id')
            ->countAllResults();

        $records = $ticket->select('office.*, user_details.*, ticket.*')
            ->join('user_details', 'user_details.id = ticket.user_id')
            ->join('office', 'office.id = ticket.office_id')
            ->orLike('user_details.last_name', $searchValue)
            ->orLike('user_details.first_name', $searchValue)
            ->orLike('office.office_name', $searchValue)
            ->orLike('ticket.severity', $searchValue)
            ->orLike('ticket.description', $searchValue)
            ->orLike('ticket.state', $searchValue)
            ->orderBy('ticket.id')
            ->findAll($rowperpage, $start);

        $data = array();
        foreach ($records as $record) {
            $data[] = array(
                "id" => $record['id'],
                "state" => $record['state'],
                "first_name" => $record['first_name'],
                "last_name" => $record['last_name'],
                "email" => $record['email'],
                "office_name" => $record['office_name'],
                "severity" => $record['severity'],
                "description" => $record['description'],
            );
        }

        $response = array(
            "draw" => intval($draw),
            "recordsTotal" => $totalRecords,
            "recordsFiltered" => $totalRecordswithFilter,
            "data" => $data
        );

        return $this->response->setStatusCode(Response::HTTP_OK)->setJSON($response);
    }

    /**
     * Create a new resource object, from "posted" parameters
     *
     * @return mixed
     */
    public function create()
    {
        
        $ticket = new \App\Models\Ticket();
        $data = $this->request->getJSON();


        if (!$ticket->validate($data)) {
            $response = array(
                'status' => 'error',
                'error' => true,
                'messages' => $ticket->errors()
            );

            return $this->response->setStatusCode(Response::HTTP_BAD_REQUEST)->setJSON($response);
        }
       
        try {
            $ticket->insert($data);
            $response = array(
                'status' => 'success',
                'error' => false,
                'messages' => 'Ticket added successfully'
            );
    
            return $this->response->setStatusCode(Response::HTTP_CREATED)->setJSON($response);
        } catch(\Exception $e) {
            $response = array(
                'status' => 'error',
                'error' => true,
                'messages' => $e->getMessage()
            );
    
            return $this->response->setStatusCode(Response::HTTP_BAD_REQUEST)->setJSON($response);
        }
       
    }

    /**
     * Add or update a model resource, from "posted" properties
     *
     * @return mixed
     */
    public function update($id = null)
    {
        $ticket = new \App\Models\Ticket();
        $data = $this->request->getJSON();
        unset($data->id);

        if (!$ticket->validate($data)) {
            $response = array(
                'status' => 'error',
                'error' => true,
                'messages' => $ticket->errors()
            );

            return $this->response->setStatusCode(Response::HTTP_NOT_MODIFIED)->setJSON($response);
        }

        $ticket->update($id, $data);
        $response = array(
            'status' => 'success',
            'error' => false,
            'messages' => 'Ticket updated successfully'
        );

        return $this->response->setStatusCode(Response::HTTP_OK)->setJSON($response);
    }

    /**
     * Delete the designated resource object from the model
     *
     * @return mixed
     */
    public function delete($id = null)
    {
        $ticket = new \App\Models\Ticket();

        if ($ticket->delete($id)) {
            $response = array(
                'status' => 'success',
                'error' => false,
                'messages' => 'Ticket deleted successfully'
            );

            return $this->response->setStatusCode(Response::HTTP_OK)->setJSON($response);
        }

        $response = array(
            'status' => 'error',
            'error' => true,
            'messages' => 'Ticket not found'
        );

        return $this->response->setStatusCode(Response::HTTP_NOT_FOUND)->setJSON($response);

    }
}
