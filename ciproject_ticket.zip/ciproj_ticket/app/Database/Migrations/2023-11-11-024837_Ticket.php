<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Ticket extends Migration
{
    public function up()
    {
        $fields = [
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'auto_increment' => true,
                'null' => false
            ],
            'user_id' =>[
                'type' => 'INT',
                'constraint' => 11,
                'null' => false
            ],
            'office_id' =>[
                'type' => 'INT',
                'constraint' => 5,
                'null' => false
            ],
            'severity' =>[
                'type' => 'VARCHAR',
                'constraint' => 5,
                'null' => false
            ],
            'description' =>[
                'type' => 'TEXT',
                'null' => false
            ],
            'state' =>[
                'type' => 'VARCHAR',
                'constraint' => 50,
                'default' => 'PENDING',
                'null' => false
            ],
            'remarks' =>[
                'type' => 'TEXT',
                'null' => false
            ],
            'created_at' =>[
                'type' => 'DATETIME',
                'null' => false
            ],
            'updated_at' =>[
                'type' => 'DATETIME',
                'null' => false
            ]
        ];

        $this->forge->addField($fields);
        $this->forge->addPrimaryKey('id');
        $this->forge->addForeignKey('user_id', 'user_details', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('office_id', 'office', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('ticket');
    }

    public function down()
    {
        $this->forge->dropTable('ticket');
    }
}
