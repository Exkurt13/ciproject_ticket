<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'WelcomeController::index');
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();

$routes->get('dashboard', 'DashboardController::index', ['filter' => 'groupfilter:admin']);
$routes->get('user', 'UserController::index', ['filter' => 'groupfilter:admin']);
$routes->get('office', 'OfficeController::index', ['filter' => 'groupfilter:admin']);
$routes->get('ticket', 'TicketController::index', ['filter' => 'auth']);

$routes->post('user/list', 'UserController::list', ['filter' => 'groupfilter:admin']);
$routes->post('office/list', 'OfficeController::list', ['filter' => 'groupfilter:admin']);
$routes->post('ticket/list', 'TicketController::list', ['filter' => 'auth']);
$routes->post('dashboard/list', 'DashboardController::list', ['filter' => 'groupfilter:admin']);

$routes->resource('user', ['controller' => 'UserController', 'except' => ['new', 'edit'], ['filter' => 'groupfilter:admin']]);
$routes->resource('office', ['controller' => 'OfficeController', 'except' => ['new', 'edit'], ['filter' => 'groupfilter:admin']]);
$routes->resource('ticket', ['controller' => 'TicketController', 'except' => ['new', 'edit'], ['filter' => 'auth']] );

service('auth')->routes($routes);
