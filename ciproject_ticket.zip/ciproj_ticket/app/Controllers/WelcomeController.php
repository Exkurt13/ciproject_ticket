<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class WelcomeController extends BaseController
{
    public function index()
    {

        $group = new \App\Models\AccountGroup();
        if (auth()->loggedIn()){
            $id = auth()->user()->id;
            $data['user_group'] = $group->find($id);
        } else{
            $data['user_group'] = "";
        }

        return view('welcome_message', $data);
    }
}
