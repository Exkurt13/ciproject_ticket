<?= $this->extend('template/admin_template'); ?>

<?= $this->section('content'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Dashboard</h1>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>

<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3><?= $critical ?></h3>
                        <p>CRITICAL</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-person"></i>
                    </div>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-orange">
                    <div class="inner">
                        <h3><?= $high ?></h3>
                        <p>HIGH</p>
                    </div>
                    <div class="icon">
                        <i class="ion"> <ion-icon name="warning"></ion-icon> </i>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3><?= $medium ?></h3>
                        <p>MEDIUM</p>
                    </div>
                    <div class="icon">
                        <i class="ion"> <ion-icon name="alert-circle"></ion-icon> </i>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3><?= $low ?></h3>
                        <p>LOW</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-alert"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-primary">
                    <div class="inner">
                        <h3><?= $pending ?></h3>
                        <p>PENDING</p>
                    </div>
                    <div class="icon">
                        <i class="ion"> <ion-icon name="enter-outline"></ion-icon> </i>
                    </div>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-blue">
                    <div class="inner">
                        <h3><?= $processing ?></h3>
                        <p>PROCESSING</p>
                    </div>
                    <div class="icon">
                        <i class="ion"> <ion-icon name="build"></ion-icon> </i>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-green">
                    <div class="inner">
                        <h3><?= $resolved ?></h3>
                        <p>RESOLVED</p>
                    </div>
                    <div class="icon">
                        <i class="ion"> <ion-icon name="checkmark-circle"></ion-icon> </i>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box bg-teal">
                    <div class="inner">
                        <h3><?= $totalTicket ?></h3>
                        <p>TOTAL TICKETS</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-ios-list"></i>
                    </div>
                </div>
            </div>
        </div>
        <table id="dataTable" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>STATUS</th>
                    <th>FIRST NAME</th>
                    <th>LAST NAME</th>
                    <th>EMAIL</th>
                    <th>OFFICE</th>
                    <th>SEVERITY</th>
                    <th>DESCRIPTION</th>
                    <th>ACTION</th>
                </tr>
            </thead>
        </table>

        <div class="modal fade" id="modalID" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-md" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Ticket Details</h5>
                        <buton type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </buton>
                    </div>
                    <div class="modal-body">
                        <form class="needs-validation" novalidate>
                            <div class="card-body">
                                <input type="hidden" id="id" name="id">
                                <div class="form-group">
                                    <label for="state">Status</label>
                                    <select class="form-control custom-select" name="state" id="state" required>
                                        <option value="PENDING">PENDING</option>
                                        <option value="PROCESSING">PROCESSING</option>
                                        <option value="RESOLVED">RESOLVED</option>
                                    </select>
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                    <div class="invalid-feedback">
                                        Please enter status.
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="content">Remarks</label>
                                    <textarea type="textarea" rows="5" class="form-control" id="remarks" name="remarks" placeholder="Enter Remarks" required></textarea>
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                    <div class="invalid-feedback">
                                        Please enter a valid remarks.
                                    </div>
                                </div>
                                <div class="form-group">
                                    <input type="hidden" id="user_id" name="user_id" >
                                    <label for="first_name">First Name</label>
                                    <input type="text" class="form-control" id="first_name" name="first_name" disabled> 
                                </div>
                                <div class="form-group">
                                    <label for="last_name">Last Name</label>
                                    <input type="text" class="form-control" id="last_name" name="last_name" disabled> 
                                </div>
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" disabled>
                                </div>
                                <div class="form-group">
                                    <label for="office_id">Office/Section/Division</label>
                                    <select class="form-control custom-select" name="office_id" id="office_id" required>
                                        <option value="">Select Office/Section/Division</option>
                                        <?php foreach ($offices as $office) : ?>
                                            <option value="<?= $office['id']; ?>"><?= $office['office_name']; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                    <div class="invalid-feedback">
                                        Please select an office.
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="severity">Severity</label>
                                    <select class="form-control custom-select" name="severity" id="severity" required>
                                        <option value="C">Critical</option>
                                        <option value="H">High</option>
                                        <option value="M">Medium</option>
                                        <option value="L">Low</option>
                                    </select>
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                    <div class="invalid-feedback">
                                        Please enter severity.
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="content">Description</label>
                                    <textarea type="textarea" rows="5" class="form-control" id="description" name="description" placeholder="Enter Description" required></textarea>
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                    <div class="invalid-feedback">
                                        Please enter a description.
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?= $this->endSection(); ?>

<?= $this->section('pagescripts'); ?>
<script>
    $(function() {

        $("form").submit(function(event) {
            event.preventDefault();

            let formdata = $(this).serializeArray().reduce(function(obj, item) {
                obj[item.name] = item.value;
                return obj;
            }, {});

            let jsondata = JSON.stringify(formdata);

            if (this.checkValidity()) {
                    $.ajax({
                        url: "<?= base_url('ticket'); ?>/" + formdata.id,
                        type: "PUT",
                        data: jsondata,
                        success: function(data) {
                            $(document).Toasts('create', {
                                class: 'bg-success',
                                title: 'Success',
                                subtitle: 'Ticket',
                                body: 'Ticket Record successfully udpated.',
                                autohide: true,
                                delay: 3000
                            });
                            $("#modalID").modal("hide");
                            table.ajax.reload();
                            clearform();
                        },
                        error: function(result) {
                            $(document).Toasts('create', {
                                class: 'bg-danger',
                                title: 'Error',
                                subtitle: 'Ticket',
                                body: 'Ticket Record not updated.',
                                autohide: true,
                                delay: 3000
                            });
                        }
                    });
                }
            });
        });


    let table = $("#dataTable").DataTable({
        responsive: true,
        processing: true,
        serverSide: true,
        ajax: {
            url: "<?= base_url('dashboard/list'); ?>",
            type: "POST"
        },
        columns: [
            {
                data: "id",
            },
            {
                data: 'state',
            },
            {
                data: 'first_name',
            },
            {
                data: 'last_name',
            },
            {
                data: 'email',
            },
            {
                data: 'office_name',
            },
            {
                data: 'severity',
            },
            {
                data: 'description',
            },
            {
                data: '',
                defaultContent: `<td>
            <button class="btn btn-warning btn-sm" id="editRow">Edit</button>
            <button class="btn btn-danger btn-sm" id="deleteRow">Delete</button>
            </td>`
            }
        ],
        "fnRowCallback": function(row, data, dataIndex, cells) {
        if (data['state'] == "RESOLVED") {
            $(row).addClass("bg-success");
        } else {
            switch (data['severity']){
                case 'C':
                    $(row).addClass("bg-danger");
                    break;
                case 'H':
                    $(row).addClass("bg-orange");
                    break;
                case 'M':
                    $(row).addClass("bg-warning");
                    break;
                case 'L':
                    $(row).addClass("bg-info");
                    break;            
            }
        }
        },
        paging: true,
        lengthChange: true,
        searching: true,
        ordering: true,
        info: true,
        autoWidth: true,
        lengthMenu: [5, 10, 20, 50]

    });

    $(document).on("click", "#editRow", function() {
        let row = $(this).parents("tr")[0];
        let id = table.row(row).data().id;

        $.ajax({
            url: "<?= base_url('ticket'); ?>/" + id,
            type: "GET",
            success: function(data) {
                $("#modalID").modal("show");
                $("#id").val(data.id);
                $("#user_id").val(data.user_id);
                $("#office_id").val(data.office_id);
                $("#severity").val(data.severity);
                $("#description").val(data.description);
                $("#state").val(data.state);
                $("#remarks").val(data.remarks);

                $.ajax({
                    url: "<?= base_url('user'); ?>/" + data.user_id,
                    type: "GET",
                    success: function(data) {
                        $("#first_name").val(data.first_name);
                        $("#last_name").val(data.last_name);
                        $("#email").val(data.email);
                    }
                });
            }
            ,
            error: function(result) {
                $(document).Toasts('create', {
                    class: 'bg-danger',
                    title: 'Error',
                    subtitle: 'Ticket',
                    body: 'Ticket Record not found.',
                    autohide: true,
                    delay: 3000
                });
            }
        });
    });

    $(document).on("click", "#deleteRow", function() {
        let row = $(this).parents("tr")[0];
        let id = table.row(row).data().id;

        if (confirm("Are you sure you want to delete this ticket record?")) {
            $.ajax({
                url: "<?= base_url('ticket'); ?>/" + id,
                type: "DELETE",
                success: function(data) {
                    $(document).Toasts('create', {
                        class: 'bg-success',
                        title: 'Success',
                        subtitle: 'Ticket',
                        body: 'Ticket Record was deleted.',
                        autohide: true,
                        delay: 3000
                    });
                    table.ajax.reload();
                },
                error: function(result) {
                    $(document).Toasts('create', {
                        class: 'bg-danger',
                        title: 'Error',
                        subtitle: 'Ticket',
                        body: 'Ticket Record not found.',
                        autohide: true,
                        delay: 3000
                    });
                }
            });
        }
    });

    function clearform() {
        $("#id").val("");
        $("#first_name").val("");
        $("#last_name").val("");
        $("#email").val("");
        $("#office_id").val("");
        $("#severity").val("");
        $("#description").val("");
        $("#state").val("");
        $("#remarks").val("");
    }

    $(document).ready(function() {
        'use strict';

        let form = $(".needs-validation");

        form.each(function() {
            $(this).on('submit', function(event) {
                if (this.checkValidity() === false) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                $(this).addClass('was-validated');
            });
        });
    });
</script>
<?= $this->endSection(); ?>