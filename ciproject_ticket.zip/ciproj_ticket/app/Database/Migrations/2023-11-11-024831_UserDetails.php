<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class User extends Migration
{
    public function up()
    {
        $fields = [
            'id' => [
                'type' => 'INT',
                'constraint' => 11,
                'auto_increment' => true,
                'null' => false
            ],
            'account_id' => [
                'type' => 'INT',
                'constraint' => 11,
                'null' => false,
                'unsigned' => true
            ],
            'first_name' =>[
                'type' => 'VARCHAR',
                'constraint' => 100,
                'null' => false
            ],
            'last_name' =>[
                'type' => 'VARCHAR',
                'constraint' => 100,
                'null' => false
            ],
            'email' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
                'null' => false
            ],
            'birthdate' =>[
                'type' => 'DATE',
                'null' => false
            ],
            'group' =>[
                'type' => 'VARCHAR',
                'constraint' => 100,
                'null' => false
            ],
            'created_at' =>[
                'type' => 'DATETIME',
                'null' => false
            ],
            'updated_at' =>[
                'type' => 'DATETIME',
                'null' => false
            ]
        ];

        $this->forge->addField($fields);
        $this->forge->addPrimaryKey('id');
        $this->forge->addUniqueKey('email');
        $this->forge->addForeignKey('account_id', 'auth_identities', 'id');
        $this->forge->createTable('user_details');
    }

    public function down()
    {
        $this->forge->dropTable('user_details');
    }
}
